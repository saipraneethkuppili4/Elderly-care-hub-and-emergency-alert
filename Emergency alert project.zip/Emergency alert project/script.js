// Exercise Tracker Section
let exerciseLog = [];

function logExercise() {
    const exerciseType = document.getElementById("exerciseType").value;
    const duration = document.getElementById("duration").value;

    if (duration.trim() === "" || isNaN(duration) || duration <= 0) {
        alert("Please enter a valid duration.");
        return;
    }

    const logEntry = `${capitalizeFirstLetter(exerciseType)}: ${duration} minutes`;
    exerciseLog.push(logEntry);

    const exerciseLogElement = document.getElementById("exerciseLog");
    const li = document.createElement("li");
    li.innerText = logEntry;
    exerciseLogElement.appendChild(li);

    // input part
    document.getElementById("exerciseType").value = "walking";
    document.getElementById("duration").value = "";
}

// Emergency part
function sendEmergencyAlert() {
    const alertStatus = document.getElementById("alertStatus");

    alertStatus.innerHTML = `<p><strong>Exercise Log:</strong></p><ul>${exerciseLog.map(entry => `<ul>${entry}</ul>`).join('')}</ul>`;
    
    alertStatus.innerHTML += "<p>Emergency alert sent! Help is on the way.</p>";
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}