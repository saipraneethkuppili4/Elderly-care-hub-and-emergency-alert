const nodemailer = require('nodemailer')
const path = require('path')
const passcode = '';

const transporter = nodemailer.createTransport({
    service:'gmail',
    host:"smpt.gmail.com",
    port:587,
    secure:false,
    auth:{
        user:'jaisandeep1559@gmail.com',
        pass:''
    }
});

const mailOptions ={
    from:{
        name:'Developer Testing',
        address : 'jaisandeep1559@gmail.com',
    },
    to:["saipraneethkuppili4@gmail.com"],
    subject:"Send email using nodemailer and gmail",
    text:"Hello World!",
    html:"<b>Hello World</b>",
    attachments:[
        {
            fileName:'sampleTest.pdf',
            path:path.join(__dirname,'sampleTest.pdf'),
            contentType:'application/pdf'
        }, {
            fileName:'imageTest.png',
            path:path.join(__dirname,'imageTest.png'),
            contentType:'image/jpg'
        },

    ]
}


const sendMail = async (transporter,mailOptions) => {
    try{
        await transporter.sendMail(mailOptions);
        console.log('Email has been sent Successfully')
    }catch(error){

    }
}

sendMail(transporter,mailOptions)
